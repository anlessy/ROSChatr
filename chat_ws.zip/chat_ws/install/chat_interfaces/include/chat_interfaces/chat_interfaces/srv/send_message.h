// generated from rosidl_generator_c/resource/idl.h.em
// with input from chat_interfaces:srv/SendMessage.idl
// generated code does not contain a copyright notice

#ifndef CHAT_INTERFACES__SRV__SEND_MESSAGE_H_
#define CHAT_INTERFACES__SRV__SEND_MESSAGE_H_

#include "chat_interfaces/srv/detail/send_message__struct.h"
#include "chat_interfaces/srv/detail/send_message__functions.h"
#include "chat_interfaces/srv/detail/send_message__type_support.h"

#endif  // CHAT_INTERFACES__SRV__SEND_MESSAGE_H_
