// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CHAT_INTERFACES__MSG__CHAT_MESSAGE_HPP_
#define CHAT_INTERFACES__MSG__CHAT_MESSAGE_HPP_

#include "chat_interfaces/msg/detail/chat_message__struct.hpp"
#include "chat_interfaces/msg/detail/chat_message__builder.hpp"
#include "chat_interfaces/msg/detail/chat_message__traits.hpp"
#include "chat_interfaces/msg/detail/chat_message__type_support.hpp"

#endif  // CHAT_INTERFACES__MSG__CHAT_MESSAGE_HPP_
