// generated from rosidl_generator_c/resource/idl.h.em
// with input from chat_interfaces:msg/ChatMessage.idl
// generated code does not contain a copyright notice

#ifndef CHAT_INTERFACES__MSG__CHAT_MESSAGE_H_
#define CHAT_INTERFACES__MSG__CHAT_MESSAGE_H_

#include "chat_interfaces/msg/detail/chat_message__struct.h"
#include "chat_interfaces/msg/detail/chat_message__functions.h"
#include "chat_interfaces/msg/detail/chat_message__type_support.h"

#endif  // CHAT_INTERFACES__MSG__CHAT_MESSAGE_H_
